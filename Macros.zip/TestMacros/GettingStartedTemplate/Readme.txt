This is a template for getting started with the CReW Test Framework.  Copy the folder "Getting Started Template" to your working folder and rename it to some thing meaningful to you.

Open and run the workflow "RunTests.yxmd" to run all of the tests.

Start by making the failing test pass.  Then take a look at some of the other tests and how they work.

After that it is time to start writing your own tests.